# CUDA 学习手册示例代码

每个 .cu 文件都是一个独立程序，开头注释里写了编译命令和最低 GPU 架构要求。

```bash
make -j8        # 编译全部
make run        # 逐个运行，看每个程序输出的 PASS / FAIL / SKIP
make gemm       # 只编译某一个
make extra      # 多 GPU 示例（需要 NCCL 和至少 2 张卡）
```

算力不够的 GPU 上，需要更高架构的程序会打印 SKIP 并跳过。*.py 是 Triton 示例，需要 `pip install torch triton`。
